package main

import (
	"myframe/router"
	"github.com/greatming/realgo"
	"myframe/config"
	"myframe/model"
)

func init()  {
	config.Init()
	model.Init()
}


func main()  {
	app := realgo.New()
	app.RegisterRouter(router.Init)
	app.StartServer()

}
