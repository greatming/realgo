package model

import (
	"github.com/greatming/realgo/lib/db"
	"myframe/config"
)

func Init() {
	db.RDB.SetCluster("hmreal", &config.DBCfg.Hmreal)
}

