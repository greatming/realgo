package model

import (
	"github.com/greatming/realgo/lib/logger"
	"github.com/greatming/realgo/lib/db"
	"fmt"
)



type User struct {
	ID uint
	Name string
	Country int
}


func (User) TableName() string {
	return "user"
}

type UserModel struct {
	Logger  *logger.Logger
	Dao *db.DBConnInfo
}


func NewUserModel(log *logger.Logger)(*UserModel, error)  {
	dao, err := db.RDB.GetCluster("hmreal")
	if err != nil{
		log.Warn("init hmreal db err")
		return nil, err
	}
	return &UserModel{
		Logger:log,
		Dao:dao,
	}, nil
}

func (u *UserModel)GetOneData()  {

	user := new(User)
	u.Dao.DB.First(user, 1)
	fmt.Println(user)
}







