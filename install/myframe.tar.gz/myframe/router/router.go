package router

import (
	"github.com/greatming/realgo"
	"myframe/controllers"
	"myframe/middleware"
	"net/http"
)

func Init(server *realgo.WebServer)  {
	server.EUSE(middleware.PrintLog)
	server.GET("/index", controllers.Index)
	server.NotFound(func(writer http.ResponseWriter, request *http.Request) {
		writer.Write([]byte("this is my custom 404 page"))
	})
}


