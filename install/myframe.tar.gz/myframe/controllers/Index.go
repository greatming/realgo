package controllers

import (
	"github.com/greatming/realgo"
	"myframe/model"
)

func Index(ctx *realgo.WebContext)  {
	res := NewResponse(ctx)
	defer res.RequestDone()


	m,_ := model.NewUserModel(ctx.Logger)
	m.GetOneData()




	ret := make(map[string]string)

	ret["name"] = "haoming"
	res.Result = ret


}
