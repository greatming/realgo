package middleware

import (
	"github.com/greatming/realgo"
)

func PrintLog(ctx *realgo.WebContext)  {
	if ctx.Logger != nil{
		ctx.Logger.Notice("request done")
	}
}

